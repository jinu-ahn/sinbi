package c104.sinbi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SinBiApplicationTests {

	@Test
	void contextLoads() {
	}

}
