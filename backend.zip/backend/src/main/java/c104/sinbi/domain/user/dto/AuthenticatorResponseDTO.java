package c104.sinbi.domain.user.dto;

import com.yubico.webauthn.data.AuthenticatorAttestationResponse;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
public class AuthenticatorResponseDTO {
    private String id;
    private String rawId;
    private AuthenticatorAttestationResponse response;
    private String type;
    private ExtensionsDto extensions;
}