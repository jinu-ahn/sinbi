package c104.sinbi.domain.user.dto;

import com.yubico.webauthn.data.PublicKeyCredentialCreationOptions;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
public class WebAuthnRegistrationRequest {
    private String phone;
    private PublicKeyCredentialCreationOptions requestOptions;
    private AuthenticatorResponseDTO response;

}