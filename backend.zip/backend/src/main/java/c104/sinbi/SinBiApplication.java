package c104.sinbi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SinBiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SinBiApplication.class, args);
	}

}
