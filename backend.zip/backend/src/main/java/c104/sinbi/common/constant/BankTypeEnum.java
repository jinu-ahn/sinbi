package c104.sinbi.common.constant;

import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
public enum BankTypeEnum {
    KB, SHINHAN, NH, IBK, HANA, WOORI, IM, KAKAO, TOSS, SINBI;

}
